package frc.robot.Commands;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants;
import frc.robot.subsystems.Feeder;
import frc.robot.subsystems.Hopper;
import frc.robot.subsystems.Shooter;

public class Shoot extends Command {
    private enum State { CLEAR, PREPARE, FEED }

    private final Hopper hopper;
    private final Feeder feeder;
    private final Shooter shooter;
    private final Timer timer = new Timer();
    private State state = State.CLEAR;

    public Shoot(Hopper hopper, Feeder feeder, Shooter shooter) {
        this.hopper = hopper;
        this.feeder = feeder;
        this.shooter = shooter;
        addRequirements(hopper, feeder, shooter);
    }

    @Override
    public void initialize() {
        state = State.CLEAR;
        timer.restart();
    }

    @Override
    public void execute() {
        switch (state) {
            case CLEAR:
                feeder.setFeederSpeed(Constants.CLEAR_POWER);
                shooter.setShooterSpeed(Constants.MANUAL_SHOOTER_SPEED); // spin up during the clear pulse
                if (timer.hasElapsed(Constants.CLEAR_TIME_SEC)) {
                    feeder.stop();
                    state = State.PREPARE;
                }
                break;

            case PREPARE:
                shooter.setShooterSpeed(Constants.MANUAL_SHOOTER_SPEED);
                if (shooter.isAtSpeed(Constants.MANUAL_SHOOTER_SPEED)) {
                    state = State.FEED;
                }
                break;

            case FEED: // latched: keeps feeding even if RPS dips when a ball leaves
                shooter.setShooterSpeed(Constants.MANUAL_SHOOTER_SPEED);
                feeder.setFeederSpeed(Constants.FEED_POWER);
                //hopper.setHopperSpeed(Constants.FEED_POWER);
                break;
        }
    }

    @Override
    public void end(boolean interrupted) {
        shooter.stop();
        feeder.stop();
        //hopper.stop();
    }

    @Override
    public boolean isFinished() {
        return false;
    }
}