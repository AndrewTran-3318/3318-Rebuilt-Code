package frc.robot.Commands;

import java.util.function.BooleanSupplier;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants;
import frc.robot.subsystems.Intake;

public class IntakeSequence extends Command {
    private enum State { HOME, DEPLOY, SETTLE, RETRACT, DONE }

    private final Intake intake;
    private final BooleanSupplier buttonHeld;
    private final Timer timer = new Timer();
    private State state = State.DONE;

    public IntakeSequence(Intake intake, BooleanSupplier buttonHeld) {
        this.intake = intake;
        this.buttonHeld = buttonHeld;
        addRequirements(intake);
    }

    @Override
    public void initialize() {
        if (intake.isHomed()) {
            enterDeploy();
        } else {
            state = State.HOME;
            timer.restart();
        }
    }

    @Override
    public void execute() {
        boolean held = buttonHeld.getAsBoolean();

        switch (state) {
            case HOME: // first use only: raise to the hall sensor, zero encoders
                intake.stopWheel();
                if (intake.getHallEffectSensorState()) {
                    finishArmAtSensor();
                    if (held) {
                        enterDeploy();
                    } else {
                        state = State.DONE;
                    }
                } else if (timer.hasElapsed(Constants.INTAKE_LIFTER_HOME_TIMEOUT_SEC)) {
                    intake.stop();
                    state = State.DONE;
                } else {
                    intake.setArmSpeed(Constants.INTAKE_LIFTER_HOMING_SPEED);
                }
                break;

            case DEPLOY: // arm setpoint is held by the SparkMax closed loop
                //intake.setWheelSpeedPercentage(Constants.INTAKE_ROLLER_POWER);
                if (!held) {
                    state = State.SETTLE;
                    timer.restart();
                }
                break;

            case SETTLE: // RB released: rollers keep going so the last balls get in
                //intake.setWheelSpeedPercentage(Constants.INTAKE_ROLLER_POWER);
                if (held) {
                    enterDeploy();
                } else if (timer.hasElapsed(Constants.INTAKE_SETTLE_TIME_SEC)) {
                    intake.stopWheel();
                    state = State.RETRACT;
                    timer.restart();
                }
                break;

            case RETRACT: // pull in until the hall sensor trips
                if (held) {
                    enterDeploy();
                } else if (intake.getHallEffectSensorState()) {
                    finishArmAtSensor();
                    state = State.DONE;
                } else if (timer.hasElapsed(Constants.INTAKE_LIFTER_HOME_TIMEOUT_SEC)) {
                    intake.stop();
                    state = State.DONE;
                } else {
                    intake.setArmSpeed(Constants.INTAKE_LIFTER_RETRACT_SPEED);
                }
                break;

            case DONE:
                break;
        }
        SmartDashboard.putString("IntakeSequenceState", state.toString());
    }

    private void enterDeploy() {
        state = State.DEPLOY;
        intake.deployArm();
    }

    // arm is at the sensor: stop, zero the encoders, and hold there
    private void finishArmAtSensor() {
        intake.stop();
        intake.resetLifterEncoder();
        intake.holdArmPosition();
    }

    @Override
    public boolean isFinished() {
        return state == State.DONE;
    }

    @Override
    public void end(boolean interrupted) {
        intake.stopWheel();
        if (interrupted) {
            intake.stop(); // cut the arm if something cancels us mid-move (or on disable)
        }
        SmartDashboard.putString("IntakeSequenceState", "IDLE");
    }
}